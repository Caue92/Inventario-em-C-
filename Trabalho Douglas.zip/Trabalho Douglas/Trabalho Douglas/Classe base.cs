﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Trabalho_Douglas
{
    public class Item
    {
        public string Nome { get; set; }
        public double Peso { get; set; }
        public double Valor { get; set; }

        // Método que será sobrescrito pelas subclasses
        public virtual void Usar()
        {
            MessageBox.Show("Usei o item");
        }

        // Retorna uma descrição básica do item
        public string Descricao()
        {
            return $"Nome: {Nome}, Peso: {Peso}kg, Valor: {Valor} moedas.";
        }
    }
}
