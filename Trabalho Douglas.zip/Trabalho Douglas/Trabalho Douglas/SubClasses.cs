﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Trabalho_Douglas
{
    public class Arma : Item
    {
        public int Dano { get; set; }

        // Sobrescrevendo o método Usar
        public override void Usar()
        {
            MessageBox.Show($"Usando a arma para causar {Dano} de dano.");
        }
    }
    public class Pocao : Item
    {
        public int Cura { get; set; }

        // Sobrescrevendo o método Usar
        public override void Usar()
        {
            MessageBox.Show($"Usando a poção e restaurando {Cura} pontos de vida.");
        }
    }
    public class Armadura : Item
    {
        public int Resistencia { get; set; }

        // Sobrescrevendo o método Usar
        public override void Usar()
        {
            MessageBox.Show($"Usando a armadura para aumentar a defesa em {Resistencia} pontos.");
        }
    }

}