﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabalho_Douglas
{
    using System;
    using System.Collections.Generic;

    public class Inventario
    {
        private List<Item> itens;

        public Inventario()
        {
            itens = new List<Item>();
        }

        // Método para adicionar item ao inventário
        public void AdicionarItem(Item item)
        {
            itens.Add(item);
            Console.WriteLine($"{item.Nome} foi adicionado ao inventário.");
        }

        // Método para remover item do inventário
        public void RemoverItem(Item item)
        {
            if (itens.Contains(item))
            {
                itens.Remove(item);
                Console.WriteLine($"{item.Nome} foi removido do inventário.");
            }
            else
            {
                Console.WriteLine($"O item {item.Nome} não está no inventário.");
            }
        }

        // Método para mostrar os itens no inventário
        public void MostrarInventario()
        {
            Console.WriteLine("Inventário:");
            foreach (var item in itens)
            {
                Console.WriteLine(item.Descricao());
            }

        }

        public List<Item> GetItens()
        {
            return itens;
        }
    }
}
