﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Trabalho_Douglas
{
    public partial class Form1 : Form
    {
        private Inventario inventario;

        private Random Randomizador = new Random();
        public Form1()

        {
            InitializeComponent();
            inventario = new Inventario();
        }

        // Método para adicionar item ao inventário
        private void btnAdicionarItem_Click(object sender, EventArgs e)
        {
            // Criar um exemplo de item (Arma, Pocao, Armadura)
            int randomico = Randomizador.Next(3);
            
            if (randomico == 0)
            {
                var arma = new Arma { Nome = "Espada", Peso = 3.0, Valor = 100, Dano = 25 };
                inventario.AdicionarItem(arma);
            }

            if(randomico == 1)
            {
                var pocao = new Pocao { Nome = "pocao", Peso = 3.0, Valor = 100, Cura = 35 };
                inventario.AdicionarItem(pocao);
            }

            if(randomico == 2)
            {
                var armadura = new Armadura { Nome = "armadura", Peso = 10.0, Valor = 100, Resistencia = 25 };
                inventario.AdicionarItem(armadura);
            }

            AtualizarInventario();
        }

        // Método para remover item do inventário
        private void btnRemoverItem_Click(object sender, EventArgs e)
        {
            if (dataGridViewInventario.SelectedRows.Count > 0)
            {
                var itemSelecionado = (Item)dataGridViewInventario.SelectedRows[0].DataBoundItem;
                inventario.RemoverItem(itemSelecionado);
                AtualizarInventario();
            }
        }

        // Método para usar o item selecionado
        private void btnUsarItem_Click(object sender, EventArgs e)
        {
            if (dataGridViewInventario.SelectedRows.Count > 0)
            {
                var itemSelecionado = (Item)dataGridViewInventario.SelectedRows[0].DataBoundItem;
                itemSelecionado.Usar();
            }
        }

        // Método para atualizar o DataGridView com o inventário
        private void AtualizarInventario()
        {
            dataGridViewInventario.DataSource = null;
            dataGridViewInventario.DataSource = inventario.GetItens();
        }
    }
}
